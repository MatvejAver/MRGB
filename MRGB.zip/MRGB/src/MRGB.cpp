#include "MRGB.h"
#include <Arduino.h>

//-----------СОЗДАНИЕ ОБЪЕКТА------------------//
MRGB::MRGB(uint8_t pin_r,uint8_t pin_g,uint8_t pin_b){
    _pins[0] = pin_r;
    _pins[1] = pin_g;
    _pins[2] = pin_b;
    for (uint8_t i = 0; i < 3; i++) pinMode(_pins[i],OUTPUT);
}

//---------------------------------------------//

//-----------ЦИФРОВЫЕ ФУНКЦИИ------------------//
void MRGB::blink(uint8_t pin,bool light){
    _light[pin] = light;
    digitalWrite(_pins[pin],_light[pin]);
}

void MRGB::blinkAuto(uint8_t pin){
    _light[pin] = !_light[pin];
    digitalWrite(_pins[pin],_light[pin]);
}

//---------------------------------------------//

//-----------АНАЛОГОВЫЕ ФУНКЦИИ----------------//

void MRGB::analogBlink(uint8_t pin,uint8_t light){
    analogWrite(_pins[pin],light);
}

//---------------------------------------------//

//--------------ДРУГИЕ ФУНКЦИИ-----------------//

void MRGB::setPin(uint8_t pin_rgb,uint8_t pin){
    if (pin != _pins[pin_rgb]){
        _pins[pin_rgb] = pin;
        pinMode(_pins[pin_rgb],OUTPUT);
    }
}

//---------------------------------------------//